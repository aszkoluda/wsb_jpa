-- Adresy
INSERT INTO ADDRESS (ID, ADDRESSLINE1, ADDRESSLINE2, CITY, POSTALCODE)
VALUES 
(1, 'ul. Kwiatowa 15', 'm. 2', 'Warszawa', '00-123'),
(2, 'ul. Długa 7', NULL, 'Kraków', '30-456'),
(3, 'ul. Słoneczna 21', 'lok. 5', 'Gdańsk', '80-001'),
(4, 'ul. Polna 3', NULL, 'Poznań', '60-001'),
(5, 'ul. Leśna 42', 'blok 3', 'Wrocław', '50-300');

-- Doctor
INSERT INTO DOCTOR (ID, FIRSTNAME, LASTNAME, TELEPHONENUMBER, EMAIL, DOCTORNUMBER, SPECIALIZATION, ADDRESSID)
VALUES
(1, 'Anna', 'Kowalska', '501123456', 'a.kowalska@example.com', 'DOC123', 'Pediatra', 1),
(2, 'Jan', 'Nowak', '502987654', 'j.nowak@example.com', 'DOC124', 'Kardiolog', 2),
(3, 'Maria', 'Lewandowska', '503555777', 'm.lewandowska@example.com', 'DOC125', 'Dermatolog', 3),
(4, 'Adam', 'Wiśniewski', '504666888', 'a.wisniewski@example.com', 'DOC126', 'Ortopeda', 4),
(5, 'Olga', 'Zając', '505999000', NULL, 'DOC127', NULL, 5);

-- Patient
INSERT INTO PATIENT (ID, FIRSTNAME, LASTNAME, TELEPHONENUMBER, EMAIL, PATIENTNUMBER, DATEOFBIRTH, ADDRESSID)
VALUES
(1, 'Tomasz', 'Wiśniewski', '503111222', 't.wisniewski@example.com', 'PAT001', '1990-04-20', 3),
(2, 'Ewa', 'Zielińska', '504333444', 'e.zielinska@example.com', 'PAT002', '1985-11-15', 1),
(3, 'Piotr', 'Maj', '505444555', NULL, 'PAT003', '2000-06-30', 2),
(4, 'Natalia', 'Krawczyk', '506666777', 'n.krawczyk@example.com', 'PAT004', '1978-02-12', 4),
(5, 'Karol', 'Bąk', '507888999', 'k.bak@example.com', 'PAT005', '1969-09-09', 5);

-- Visit
INSERT INTO VISIT (ID, DESCRIPTION, TIME, DOCTORID, PATIENTID)
VALUES
(1, 'Kontrola pediatryczna', '2025-04-01 09:30:00', 1, 1),
(2, 'Badanie EKG', '2025-04-02 14:00:00', 2, 2),
(3, 'Konsultacja dermatologiczna', '2025-04-03 11:00:00', 3, 3),
(4, 'Kontrola po złamaniu', '2025-04-04 15:30:00', 4, 4),
(5, 'Ogólna konsultacja', '2025-04-05 10:15:00', 5, 5);

-- Medical_treatment
INSERT INTO MEDICAL_TREATMENT (ID, DESCRIPTION, TYPE, VISITID)
VALUES
(1, 'Szczepienie przeciwko grypie', 'Szczepienie', 1),
(2, 'EKG serca i analiza wyników', 'Diagnostyka', 2),
(3, 'Leczenie trądziku', 'Farmakoterapia', 3),
(4, 'Fizjoterapia kończyny dolnej', 'Rehabilitacja', 4),
(5, 'Badanie ogólne + morfologia', 'Diagnostyka', 5),
(6, 'Wydanie zwolnienia lekarskiego', 'Administracyjne', 1);