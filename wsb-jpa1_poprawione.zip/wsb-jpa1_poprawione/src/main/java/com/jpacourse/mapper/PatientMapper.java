package com.jpacourse.mapper;

import com.jpacourse.dto.PatientTO;
import com.jpacourse.persistence.entity.PatientEntity;

public class PatientMapper {

    // Z ENTITY do DTO
    public static PatientTO mapToTO(PatientEntity entity) {
        if (entity == null) return null;

        PatientTO to = new PatientTO();
        to.setId(entity.getId());
        to.setFirstName(entity.getFirstName());
        to.setLastName(entity.getLastName());
        to.setPesel(entity.getPesel());
        to.setBirthDate(entity.getBirthDate());

        return to;
    }

    // Z DTO do ENTITY
    public static PatientEntity mapToEntity(PatientTO to) {
        if (to == null) return null;

        PatientEntity entity = new PatientEntity();
        entity.setId(to.getId());
        entity.setFirstName(to.getFirstName());
        entity.setLastName(to.getLastName());
        entity.setPesel(to.getPesel());
        entity.setBirthDate(to.getBirthDate());

        return entity;
    }
}
