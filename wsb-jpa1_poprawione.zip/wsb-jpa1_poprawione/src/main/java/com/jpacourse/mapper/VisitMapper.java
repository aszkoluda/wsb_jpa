package com.jpacourse.mapper;

import com.jpacourse.dto.VisitTO;
import com.jpacourse.persistence.entity.MedicalTreatmentEntity;
import com.jpacourse.persistence.entity.VisitEntity;
import com.jpacourse.persistence.entity.Doctor;

import java.util.stream.Collectors;

public class VisitMapper {

    public static VisitTO mapToTO(VisitEntity entity) {
        if (entity == null) return null;

        VisitTO to = new VisitTO();
        to.setDate(entity.getDate());

        // Mapowanie danych doktora
        if (entity.getDoctor() != null) {
            Doctor doctor = entity.getDoctor();
            to.setDoctorFirstName(doctor.getFirstName());
            to.setDoctorLastName(doctor.getLastName());
        } else {
            to.setDoctorFirstName("");
            to.setDoctorLastName("");
        }

        // Mapowanie typów zabiegów
        to.setTreatmentTypes(
                entity.getTreatmentTypes()
                        .stream()
                        .map(MedicalTreatmentEntity::getType)  // Zakładając, że getType() zwraca TreatmentType
                        .collect(Collectors.toList())
        );

        return to;
    }
}



