package com.jpacourse.persistence.dao.custom;

public interface PatientDaoCustom {
    void exampleCustomMethod();
}
