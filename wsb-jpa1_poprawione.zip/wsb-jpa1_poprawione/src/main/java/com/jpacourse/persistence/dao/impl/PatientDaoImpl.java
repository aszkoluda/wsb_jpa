package com.jpacourse.persistence.dao.impl;

import com.jpacourse.persistence.dao.custom.PatientDaoCustom;
import org.springframework.stereotype.Repository;

@Repository
public class PatientDaoImpl implements PatientDaoCustom {

    @Override
    public void exampleCustomMethod() {
        System.out.println("Custom method works!");
    }
}
