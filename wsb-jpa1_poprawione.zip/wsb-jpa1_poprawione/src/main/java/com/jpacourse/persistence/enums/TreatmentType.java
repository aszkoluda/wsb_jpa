package com.jpacourse.persistence.enums;

public enum TreatmentType {
	PHYSICAL_THERAPY,
	SURGERY,
	CONSULTATION,
	OTHER
}
