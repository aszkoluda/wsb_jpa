package com.jpacourse.persistence.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import jakarta.persistence.*;

@Entity
@Table(name = "VISIT")
public class VisitEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private LocalDate date;

	private String description;

	private boolean completed;

	@Column(nullable = false)
	private LocalDateTime time;

	@ManyToOne
	@JoinColumn(name = "doctor_id")
	private Doctor doctor;

	// Nowe pole: lista zabiegów medycznych
	@OneToMany(mappedBy = "visit")  // Zdefiniowanie relacji z MedicalTreatmentEntity
	private List<MedicalTreatmentEntity> treatmentTypes;

	// Gettery i Settery

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	public LocalDateTime getTime() {
		return time;
	}

	public void setTime(LocalDateTime time) {
		this.time = time;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	// Getter i Setter dla treatmentTypes
	public List<MedicalTreatmentEntity> getTreatmentTypes() {
		return treatmentTypes;
	}

	public void setTreatmentTypes(List<MedicalTreatmentEntity> treatmentTypes) {
		this.treatmentTypes = treatmentTypes;
	}
}
