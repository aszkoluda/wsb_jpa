package com.jpacourse.persistence.entity;

import jakarta.persistence.*;
import com.jpacourse.persistence.enums.TreatmentType;

@Entity
public class MedicalTreatmentEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Enumerated(EnumType.STRING)
	private TreatmentType type;

	@ManyToOne
	@JoinColumn(name = "visit_id")
	private VisitEntity visit; // Relacja z VisitEntity

	// Gettery i Settery
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TreatmentType getType() {
		return type;
	}

	public void setType(TreatmentType type) {
		this.type = type;
	}

	public VisitEntity getVisit() {
		return visit;
	}

	public void setVisit(VisitEntity visit) {
		this.visit = visit;
	}
}
